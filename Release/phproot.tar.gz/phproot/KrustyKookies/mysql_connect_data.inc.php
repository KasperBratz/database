<?php
	$host = "puccini.cs.lth.se";
	$userName = "db148";
	$password = "kasper";
	$database = "db148";
?>
