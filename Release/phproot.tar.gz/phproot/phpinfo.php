<html>
<title>PHP Info Page</title>
<body>
<?php
	phpinfo();
?>
</body>
</html>
